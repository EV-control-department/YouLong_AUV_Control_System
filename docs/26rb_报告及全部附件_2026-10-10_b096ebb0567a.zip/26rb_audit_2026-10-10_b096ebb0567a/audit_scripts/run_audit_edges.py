import sys
from pathlib import Path
root=Path('/audit')
for p in (root/'workspace_auv/src').iterdir():
 if p.is_dir():sys.path.insert(0,str(p))
import pytest
raise SystemExit(pytest.main(['/audit-results/test_audit_edges.py','-q','-p','no:cacheprovider','--junitxml=/audit-results/foxy-audit-edge-tests.xml']))
