from pathlib import Path
import shutil,hashlib,json
src=Path('/home/doc049/Documents/Codex/2026-10-09/dui-y/outputs');dst=Path('/home/doc049/dev/UUV/YouLong_AUV_Control_System/docs')
name='26rb_全流程超时参数速度与失败处理审查_2026-10-10.md';annex='26rb_audit_2026-10-10'
shutil.copy2(src/name,dst/name)
shutil.copytree(src/annex,dst/annex,dirs_exist_ok=True)
files=[src/name]+list((src/annex).rglob('*'));mismatch=[];count=0
for p in files:
 if not p.is_file():continue
 q=dst/p.relative_to(src);count+=1
 if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(q.read_bytes()).digest():mismatch.append(str(q))
print(json.dumps({'report':str(dst/name),'copied_files':count,'hash_mismatches':mismatch},ensure_ascii=False))
if mismatch:raise SystemExit(1)
