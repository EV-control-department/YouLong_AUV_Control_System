from pathlib import Path
import sys,os,pytest
root=Path(os.environ.get('AUDIT_SOURCE','/audit'))
for p in (root/'workspace_auv/src').iterdir():
 if p.is_dir():sys.path.insert(0,str(p))
paths=['auv_description/test/test_real_geometry.py','uv_camera/test','uv_perception/test/test_ring_orientation.py','uv_perception/test/test_model_classes.py','uv_perception/test/test_perception_contract.py','uv_perception/test/test_calibrated_localizer.py','uv_perception/test/test_localizer_geometry.py','uv_localization/test/test_estimator_math.py']
print('Offline camera / geometry / orientation / localization tests',flush=True)
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider']+[str(root/'workspace_auv/src'/p) for p in paths]+['--junitxml='+os.environ.get('AUDIT_XML','/audit-results/foxy-extra-tests.xml')]))
