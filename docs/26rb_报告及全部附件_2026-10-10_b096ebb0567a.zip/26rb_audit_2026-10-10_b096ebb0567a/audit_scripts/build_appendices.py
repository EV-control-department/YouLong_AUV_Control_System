from pathlib import Path
import yaml,json,ast,csv,hashlib
root=Path('work/audit_snapshot');out=Path('work/catalog');text=[]
text+=['\n## 附录 B. 相机完整标定与共享类别\n','本附录保留配置文件精度；实时CameraInfo/calibration_id与启动覆盖仍优先。K按行列给出，D顺序[k1,k2,p1,p2,k3]。\n']
for camera in ['front','down']:
 p=root/'workspace_auv/src/uv_camera/stereos'/f'{camera}.yaml';doc=yaml.safe_load(p.read_text())
 for mode,value in doc['modes'].items():
  text+=['\n### B. '+camera+' / '+mode+'\n','```yaml\n'+yaml.safe_dump(value,allow_unicode=True,sort_keys=False)+'```\n']
p=root/'workspace_auv/src/uv_perception/weights/HQQ7_aug.yaml'
text+=['\n### B. canonical类别与目标语义\n','```yaml\n'+p.read_text()+'```\n']
text+=['\n## 附录 C. ROS节点参数代码默认值与BasicMotion配置\n','`declare_parameter` AST清单来自本次快照；这不是运行节点param dump。动态参数名会保留表达式；启动launch/YAML/环境可覆盖默认。下表含所收录包其他节点参数，因此是相关源码的超集，不表示每一项都参与26rb。\n','| 源码:行 | 参数名表达式 | 代码默认表达式 |\n|---|---|---|\n']
with (out/'node_parameter_defaults.csv').open() as f:
 for row in csv.DictReader(f):
  text.append('| `'+row['source']+':'+row['line']+'` | `'+row['key'].replace('|','\\|')+'` | `'+row['default_expression'].replace('|','\\|')+'` |\n')
p=root/'workspace_auv/src/uv_control/config/default.yaml'
text+=['\n### C. BasicMotion默认配置原文\n','```yaml\n'+p.read_text()+'```\n']
launch=[]
for p in (root/'workspace_auv/src').rglob('*.py'):
 if '/launch/' not in str(p):continue
 try:tree=ast.parse(p.read_text())
 except (SyntaxError,UnicodeError):continue
 for n in ast.walk(tree):
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='DeclareLaunchArgument':
   launch.append([str(p.relative_to(root)),n.lineno,ast.unparse(n.args[0]) if n.args else '',next((ast.unparse(k.value) for k in n.keywords if k.arg=='default_value'),'[none]')])
with (out/'launch_argument_defaults.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['source','line','argument_expression','default_expression']);w.writerows(launch)
text+=['\n## 附录 D. 附件索引与证据使用方法\n','附件目录为本报告同目录下 `26rb_audit_2026-10-10/`，目录README列出全部文件。CSV为UTF-8并保留原始表达式，不把变量表达式伪造为常量；打开时可按task/function过滤。\n',
'| 附件 | 内容及限制 |\n|---|---|\n',
'| `catalog/task_parameters.csv/json` | 297项任务展开参数；YAML键→运行时键；与附录A对应 |\n',
'| `catalog/active_mission_expanded.json` | 当前4项有效mission及合并的initial_pose/params/on_failure |\n',
'| `catalog/all_calls.csv` | 相关7模块全部2923个AST调用点，用于复核专用清单筛选边界；包含数学/日志/其他旧任务调用，不是2923个物理动作 |\n',
'| `catalog/weight_file_metadata.json` | HQQ6/HQQ7权重文件存在性、size和SHA256；未据此宣称模型推理效果或读取到实际权重labels |\n',
'| `catalog/action_calls.csv` | 相关7个模块的动作/子阶段调用点，含task_runner其他旧任务，是链条调用超集；不是每次运行的轨迹 |\n',
'| `catalog/clock_wait_calls.csv` | monotonic/sleep/wait等调用点；表达式与所属函数用于检查未受deadline约束的等待 |\n',
'| `catalog/failure_calls.csv` | 失败构造/抛出调用点；实际最终failure code需结合wrapper/fallback |\n',
'| `catalog/parameter_reads.csv` | 参数读取及fallback表达式；含其他字典.get，不能把每行都当任务参数 |\n',
'| `catalog/node_parameter_defaults.csv` | 节点declare_parameter默认表达式，动态line.*另看control/default.yaml |\n',
'| `catalog/launch_argument_defaults.csv` | 启动参数默认值及源码位置，包含末次前HQQ6/下HQQ7覆盖 |\n',
'| `catalog/source_aliases.csv` | 正文短文件名对应的完整快照路径与hash；同名文件保留多条，需结合包/函数定位 |\n',
'| `catalog/function_index.csv` | 函数名与快照行号，便于源发生变化后按名重新定位 |\n',
'| `catalog/scene_entities.csv` | 固定及仓库seeded场景434条实体/关键点/变换/几何记录；不冒充当前临时生成seed目录 |\n',
'| `catalog/installed_config_comparison.json`、`installed_mission_load_probe.txt` | 旧install与源码配置hash差异及加载器失败 |\n',
'| `catalog/live_drift_comparison.json`、`live_drift.patch` | 首快照至末次复核两处启动入口变动，已纳入本报告 |\n',
'| `catalog/snapshot_manifest_expanded.json` | 所收录快照文件的size/SHA256；权重只记录hash，不在源证据压缩包中重复大模型 |\n',
'| `catalog/line_kinematic_probe.json` | 15组模型演算结果与条件 |\n',
'| `logs/` | pytest及固件配置/构建/测试日志、XML；失败与禁用结果保留 |\n',
'| `audit_scripts/` | 本次边界探针、清单生成、运动学探针和离线测试入口；只针对快照，不是实艇运行脚本 |\n',
'| `frozen_sources.zip` | 本次任务/控制/感知/几何/场景与固件应用源证据（不含权重、HAL、Eigen和构建产物）；用于复核报告引用，不宣称独立可编译全部工程 |\n',
'\nCSV中的source相对仓库根。可用 `sha256sum` 对当前文件与manifest对应行核验；hash不同先做diff，再决定原结论是否还适用。报告的当前值只针对该快照，实际运行值须以第18章列出的运行记录为证。\n']
(out/'appendix_other.md').write_text(''.join(text))
print(json.dumps({'launch_arguments':len(launch),'appendix_bytes':len(''.join(text).encode())}))
