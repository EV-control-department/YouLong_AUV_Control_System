from pathlib import Path
import shutil,json,zipfile,hashlib,datetime,re,subprocess
base=Path.cwd();work=base/'work';outputs=base/'outputs';outputs.mkdir(exist_ok=True)
name='26rb_全流程超时参数速度与失败处理审查_2026-10-10.md';annex=outputs/'26rb_audit_2026-10-10';annex.mkdir(exist_ok=True)
for part in ['catalog','logs','audit_scripts','raw_configs']:(annex/part).mkdir(exist_ok=True)
for p in (work/'catalog').iterdir():
 if p.is_file() and p.name not in {'appendix_parameters.md','appendix_other.md'}:shutil.copy2(p,annex/'catalog'/p.name)
for p in work.iterdir():
 if p.suffix in {'.log','.xml'}:shutil.copy2(p,annex/'logs'/p.name)
shutil.copy2(work/'firmware-test-build/firmware-results.xml',annex/'logs/firmware-results.xml')
for p in work.glob('*.py'):shutil.copy2(p,annex/'audit_scripts'/p.name)
snap=work/'audit_snapshot'
configs=['workspace_auv/src/uv_task/config','workspace_auv/src/uv_camera/stereos','workspace_auv/src/uv_control/config','workspace_auv/src/auv_description/config','workspace_auv/src/uv_bringup/config']
for rel in configs:
 for p in (snap/rel).rglob('*'):
  if not p.is_file():continue
  dest=annex/'raw_configs'/p.relative_to(snap);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in (snap/'workspace_auv/src/uv_perception/weights').glob('*.yaml'):
 dest=annex/'raw_configs'/p.relative_to(snap);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in (work/'final_live_overrides').rglob('*'):
 if not p.is_file():continue
 dest=annex/'final_live_overrides'/p.relative_to(work/'final_live_overrides');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in (work/'provenance').rglob('*'):
 if not p.is_file():continue
 dest=annex/'provenance'/p.relative_to(work/'provenance');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
allowed={'.py','.yaml','.yml','.urdf','.scn','.xml','.cpp','.hpp','.h','.c','.msg','.srv','.action','.txt'};frozen=[]
with zipfile.ZipFile(annex/'frozen_sources.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(snap.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or 'build' in p.parts or 'Thirdparty' in p.parts:continue
  if p.suffix not in allowed or p.is_relative_to(snap/'docs'):continue
  if 'HAL' in p.parts and p.name!='iwdg.c':continue
  rel=p.relative_to(snap);z.write(p,str(rel));frozen.append(str(rel))
(annex/'catalog/frozen_sources_filelist.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n')
main=(work/'report_main.md').read_text()
summary='''## 阅读入口与需优先处理的结论

**末次配置优先看第20章：抓取YAML新改为环松爪270°，当前校验器实际拒绝任务和mission加载；球/环新抓深为0.65/0.58m，且部分重试深度与15s预算冲突。正文1–19及附录A保留此前已测试基线，末次候选另附原文与参数。**

本文按当前磁盘源码审查，并逐项给出“已实现行为、失败后实际去向、尚未实现的处理”。建议先读第1章实际mission、第12章失败矩阵、第13章超时/速度总表、第16章验证结果和第17章改进契约，再查各任务细节。

- 当前有效mission没有撞球和过门；简单取消注释后顺序也不符合指定流程。
- runner在多数任务失败后继续下一任务；局部取消未确认保护尚未成为全局运动互锁。
- 已测试基线组合抓取工作深度0.2m，球/环机器人抓深各为0.44、0.49、0.54m（末次新值见第20章）；两个爪的参考点深度相差16cm。
- 圆盘爪URDF与登记/测试差6cm，几何测试真实失败；旧Foxy安装mission与当前加载器也不兼容。
- 撞球fallback可以未确认撞击而返回OK；投放只确认指令流程，返航上浮按时间估算，均缺少更强的实物结果证明。
- 导航无效时MCU可能拒收零速度，ARM心跳又继续有效；“ROS发零”不足以证明实际停车。
- 附录列297项任务参数；附件含323处动作/灯光/舵机调用、169处计时等待、78项节点默认、91项launch默认及434条场景记录，保留快照、测试失败和原始配置。

目录：0审查基准；1实际mission；2共同约定；3启动/到点；4撞球；5过门；6球环抓取；7投放；8返航；9物品/几何；10控制与固件；11旧抓球差异；12失败矩阵；13超时速度总表；14部署一致性；15检测与量化；16验证；17恢复契约；18现场证据；19参数校验；20末次抓取配置及加载阻断；附录A–D。

'''
main=main.replace('## 0. 审查基准与读法',summary+'## 0. 审查基准与读法',1)
report=main+(work/'catalog/appendix_parameters.md').read_text()+(work/'catalog/appendix_other.md').read_text()
# Turn filenames in attachment table into relative clickable links.
for rel in ['catalog/task_parameters.csv','catalog/active_mission_expanded.json','catalog/action_calls.csv','catalog/clock_wait_calls.csv','catalog/failure_calls.csv','catalog/parameter_reads.csv','catalog/node_parameter_defaults.csv','catalog/launch_argument_defaults.csv','catalog/function_index.csv','catalog/scene_entities.csv','catalog/snapshot_manifest_expanded.json','catalog/line_kinematic_probe.json','frozen_sources.zip']:
 report=report.replace('`'+rel+'`','['+rel+'](26rb_audit_2026-10-10/'+rel+')')
(outputs/name).write_text(report)
readme='''# 26rb审查附件

主报告：[`../26rb_全流程超时参数速度与失败处理审查_2026-10-10.md`](../26rb_全流程超时参数速度与失败处理审查_2026-10-10.md)。

- catalog：展开参数、调用点、失败构造、时间等待、节点/launch默认、场景实体、hash与安装差异。
- raw_configs：审查时的任务mission/独立任务、相机K/D、控制器、几何登记及真实启动profile。
- logs：各轮离线测试/构建日志及XML；包含失败和环境问题，不能仅凭文件名认为全部通过。
- audit_scripts：审查脚本与11个边界探针；不用于连接实艇。脚本路径按审查工作区和容器布局编写，复跑前需恢复匹配快照及ROS生成消息环境。
- frozen_sources.zip：关键源证据；不含权重、HAL库、Eigen和编译产物，不是独立完整可编译工程。仅含iwdg.c这个HAL配置证据例外。
- provenance：审查中两处launch首快照，配合catalog/live_drift.patch查看末次模型路径变化。

报告没有修改mission或控制逻辑。末次候选环松爪270°导致task/mission校验失败，见报告第20章及final_live_overrides；raw_configs/frozen_sources保留已测试基线。相机补测最终112通过1失败；固件154通过1失败1禁用；任务387、控制64、边界探针11通过。主机和Foxy重复执行同一任务/边界集合，不重复计为新用例。
'''
(annex/'README.md').write_text(readme)
print(json.dumps({'report':str(outputs/name),'lines':len(report.splitlines()),'utf8_bytes':len(report.encode()),'frozen_source_files':len(frozen),'attachment_files':sum(p.is_file() for p in annex.rglob('*'))},ensure_ascii=False))
