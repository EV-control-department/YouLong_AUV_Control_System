from pathlib import Path
import sys,os,json,csv,ast,yaml,hashlib,shutil
root=Path('work/audit_snapshot').resolve(); out=Path('work/catalog');out.mkdir(exist_ok=True)
for p in (root/'workspace_auv/src').iterdir():
 if p.is_dir():sys.path.insert(0,str(p))
from uv_task.config_loader import load_task,load_mission,TASK_SCHEMAS,_flatten_params
from uv_task.gate_config import validate_gate_params
from uv_task.hit_ball_config import validate_hit_params
wanted=['start','26rb_hit_balls','26rb_gate_task','26rb_grab_ball_ring','26rb_drop_ball_target_rack','return_origin','26rb_grab_golf']
base=root/'workspace_auv/src/uv_task/config'
expanded={}; rows=[]
for name in wanted:
 path=base/'tasks'/f'{name}.yaml'
 item=load_task(path)[0];p=item['params']
 if name=='26rb_hit_balls':p=validate_hit_params(p)
 if name=='26rb_gate_task':p=validate_gate_params(p,complete=True)
 expanded[name]=p
 raw=yaml.safe_load(path.read_text())['params'] or {}
 def walk(value, trail=()):
  for k,v in value.items():
   if isinstance(v,dict):yield from walk(v,trail+(k,))
   else:yield '.'.join(trail+(k,)),v
 provenance={}
 for dotted,v in walk(raw):
  nested=v
  for key in reversed(dotted.split('.')):nested={key:nested}
  flat=_flatten_params(nested,TASK_SCHEMAS[name],task_name=name)
  provenance[next(iter(flat))]=dotted
 for k,v in p.items():rows.append([name,provenance.get(k,'[code default]'),k,json.dumps(v,ensure_ascii=False),str(path.relative_to(root))])
(out/'task_parameters.json').write_text(json.dumps(expanded,ensure_ascii=False,indent=2)+'\n')
(out/'active_mission_expanded.json').write_text(json.dumps(load_mission(base/'missions/robocup_26.yaml'),ensure_ascii=False,indent=2)+'\n')
with (out/'task_parameters.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['task','yaml_key','runtime_key','value','source']);w.writerows(rows)
# AST inventory is evidence for defaults and hardcoded values, not a claim every get belongs to task params.
gets=[];declares=[];functions=[]
selected=list((root/'workspace_auv/src').rglob('*.py'))
for path in selected:
 if '/test/' in str(path) or path.name=='setup.py':continue
 try:tree=ast.parse(path.read_text())
 except (SyntaxError,UnicodeError):continue
 for n in ast.walk(tree):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   functions.append([str(path.relative_to(root)),n.lineno,n.name])
  if not isinstance(n,ast.Call) or not isinstance(n.func,ast.Attribute) or not n.args:continue
  if n.func.attr=='get' and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):
   gets.append([str(path.relative_to(root)),n.lineno,ast.unparse(n.func.value),n.args[0].value,ast.unparse(n.args[1]) if len(n.args)>1 else '[None]'])
  if n.func.attr=='declare_parameter':
   declares.append([str(path.relative_to(root)),n.lineno,ast.unparse(n.args[0]),ast.unparse(n.args[1]) if len(n.args)>1 else '[unspecified]'])
for filename,header,data in [('parameter_reads.csv',['source','line','receiver','key','fallback_expression'],gets),('node_parameter_defaults.csv',['source','line','key','default_expression'],declares),('function_index.csv',['source','line','function'],functions)]:
 with (out/filename).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(sorted(data))
append=['\n## 附录 A. 经仓库配置加载器展开的任务参数全表\n', '以下表格保留 YAML 键与运行时键的对应关系。撞球和过门附带运行时校验器补齐的代码默认值；其他任务构造器的 fallback 另见 `parameter_reads.csv`，不能把本表缺省项误当成不存在。`[code default]` 表示任务 YAML 未显式设置。active mission 最终合并值见 `active_mission_expanded.json`；未启用任务的本表是独立任务配置，不表示已经在 mission 启用。\n']
for name in wanted:
 append+=['\n### A.'+str(wanted.index(name)+1)+' '+name+'\n','| YAML 键 | 运行时键 | 数值 |\n|---|---|---|\n']
 for row in rows:
  if row[0]==name:append.append('| `'+row[1]+'` | `'+row[2]+'` | `'+row[3].replace('|','\\|')+'` |\n')
(out/'appendix_parameters.md').write_text(''.join(append))
print(json.dumps({'task_fields':len(rows),'parameter_reads':len(gets),'node_parameters':len(declares),'functions':len(functions)}))
