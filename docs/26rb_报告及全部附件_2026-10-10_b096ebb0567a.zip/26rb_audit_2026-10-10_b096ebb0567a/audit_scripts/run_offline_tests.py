from pathlib import Path
import sys,os,pytest,cv2,numpy
root=Path(os.environ.get('AUDIT_SOURCE','/audit'))
for p in (root/'workspace_auv/src').iterdir():
 if p.is_dir():sys.path.insert(0,str(p))
print('BASELINE',sys.version,os.environ.get('ROS_DISTRO'),numpy.__version__,cv2.__version__,flush=True)
paths=[root/'workspace_auv/src/uv_task/test']
if os.environ.get('AUDIT_CONTROL_ONLY'):
 paths=[root/'workspace_auv/src/uv_control/test/test_line_guidance.py',root/'workspace_auv/src/uv_control/test/test_start_origin.py']
args=['-q','-p','no:cacheprovider']+list(map(str,paths))+['--junitxml='+os.environ.get('AUDIT_XML','/audit-results/foxy-task-tests.xml')]
raise SystemExit(pytest.main(args))
