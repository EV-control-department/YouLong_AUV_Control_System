from pathlib import Path
import sys,json,math
sys.path.insert(0,str(Path('work/audit_snapshot/workspace_auv/src/uv_control').resolve()))
from uv_control.line_guidance import LineConfig,LineGuidance,norm
rows=[]
for length in (.5,1.6,2.2):
 for tau in (0.,.1,.3,.6,1.):
  g=LineGuidance((0,0,.2),0,(length,0,0),.15,LineConfig());p=(0.,0.,.2);v=(0.,0.,0.);dt=.05;t=0.;hold=None;phases={};at8=None
  for step in range(3000):
   if g.reached(p,v,0):
    if hold is None:hold=t
    cmd=(0.,0.,0.);phase='HOLD'
    if t-hold>=1.:break
   else:
    hold=None;cmd,phase,s=g.step(p,v,dt)
   phases.setdefault(phase,round(t,3))
   alpha=1. if tau==0 else 1.-math.exp(-dt/tau)
   v=tuple(a+alpha*(b-a) for a,b in zip(v,cmd));p=tuple(a+dt*b for a,b in zip(p,v));t+=dt
   if at8 is None and t>=8.-1e-9:at8={'x_m':round(p[0],6),'vx_mps':round(v[0],6),'phase':phase}
  rows.append({'length_m':length,'lag_tau_s':tau,'model':'first_order_velocity_lag; ideal_position_hold_zero_velocity; no current or hardware','complete_s':round(t,3),'final_x_m':round(p[0],6),'at8':at8,'first_phase_times_s':phases})
Path('work/catalog/line_kinematic_probe.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(r['length_m'],r['lag_tau_s'],r['complete_s'],r['final_x_m'],r['at8'])
