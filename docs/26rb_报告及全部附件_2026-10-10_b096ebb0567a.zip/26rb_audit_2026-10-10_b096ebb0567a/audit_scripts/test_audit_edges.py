"""Audit probes, offline only: exercise ambiguous contracts against snapshot code."""
import math,threading
from collections import deque
from importlib import import_module
from types import SimpleNamespace as NS
import numpy as np
import pytest
from uv_task.task_outcome import TaskOutcome
from uv_task.down_camera_servo import DownCameraPriority,best_detection
from uv_task.task_runner import TaskRunnerNode
from uv_msgs.msg import TaskStatus
runner=import_module('uv_task.task_runner')
hit=import_module('uv_task.26rb_hit_balls')

class Clock:
 def __init__(self):self.t=100.
 def now(self):return self.t
 def sleep(self,dt):self.t+=max(0.,dt)

def logger():
 logs=[]
 return NS(info=logs.append,warn=logs.append,warning=logs.append,error=logs.append),logs

@pytest.mark.parametrize('mode',['failure','exception','cancel_unconfirmed'])
def test_runner_advances_after_failure_without_stop_latch(mode):
 log,_=logger();calls=[]
 node=NS(tasks=[{'name':'first','params':{}},{'name':'second','params':{}}],_cmd_x=0,_cmd_y=0,_cmd_z=.2,_cmd_yaw=0,get_logger=lambda:log,_select_failure_override=lambda *a:None)
 def execute(name,params,initial_pose=None):
  calls.append(name)
  if name=='first':
   if mode=='exception':raise RuntimeError('transport failure')
   return TaskOutcome.failed('first.motion','BLINE cancellation unconfirmed' if mode=='cancel_unconfirmed' else 'failed')
  return TaskOutcome.ok()
 node._execute_task=execute
 TaskRunnerNode.run_task_list(node)
 assert calls==['first','second'] and node._mission_status_code==TaskStatus.STATUS_ERROR
 assert not node.stopped

def test_runner_stop_latch_halts_next_task():
 log,_=logger();calls=[]
 node=NS(tasks=[{'name':'first','params':{}},{'name':'second','params':{}}],_cmd_x=0,_cmd_y=0,_cmd_z=.2,_cmd_yaw=0,get_logger=lambda:log,_select_failure_override=lambda *a:None)
 def execute(name,params,initial_pose=None):
  calls.append(name);node.stopped=True;return TaskOutcome.failed('first.cancelled','stop')
 node._execute_task=execute
 TaskRunnerNode.run_task_list(node)
 assert calls==['first'] and node._mission_status_code==TaskStatus.STATUS_PAUSED

@pytest.mark.parametrize('z',[1.21,2.0])
def test_return_too_deep_refuses_before_issuing_even_zero(z):
 log,_=logger();calls=[]
 node=NS(stopped=False,_latest_robot_pose=lambda:(0,0,z,0,0,0),get_logger=lambda:log,_send_body_velocity=lambda **kw:calls.append(kw))
 assert TaskRunnerNode._task_return_origin(node,{}) is False
 assert not calls and node._last_motion_failure_kind=='timeout'

def test_return_completes_from_elapsed_time_despite_unchanged_measured_z(monkeypatch):
 clock=Clock();log,_=logger();calls=[]
 monkeypatch.setattr(runner.time,'monotonic',clock.now);monkeypatch.setattr(runner.time,'sleep',clock.sleep)
 def send(**kw):calls.append(kw);return True,''
 node=NS(stopped=False,_latest_robot_pose=lambda:(0,0,.2,0,0,0),get_logger=lambda:log,_send_body_velocity=send,_format_motion_context=lambda text:text)
 assert TaskRunnerNode._task_return_origin(node,{}) is True
 assert node._latest_robot_pose()[2]==.2 and node._cmd_z==-.3
 assert clock.t==pytest.approx(110.)
 assert calls[-1].get('vertical_mps',0)==0 and all('wait_deadline' not in c for c in calls)

def test_down_callback_accepts_repeated_capture_and_old_header(monkeypatch):
 clock=Clock();monkeypatch.setattr(runner.time,'monotonic',clock.now)
 monkeypatch.setattr(runner,'bind_detection_geometry',lambda *args:True)
 node=NS(_perception_lock=threading.RLock(),_down_detections={},_down_detection_sequence=0,_down_detection_events=deque(maxlen=256))
 msg=NS(camera_name='down_left',capture_id=12,header=NS(stamp=NS(sec=1,nanosec=0)),detections=[])
 TaskRunnerNode._det_cb(node,msg);clock.sleep(.1);TaskRunnerNode._det_cb(node,msg)
 assert node._down_detection_sequence==2
 assert node._down_detections['down_left'][0]==clock.t

def test_down_priority_has_no_minimum_confidence_or_header_age_check(monkeypatch):
 clock=Clock();mod=import_module('uv_task.down_camera_servo');monkeypatch.setattr(mod.time,'monotonic',clock.now)
 log,_=logger();node=NS(_perception_lock=threading.RLock(),_down_detection_sequence=0,_down_detection_events=deque(maxlen=256),get_logger=lambda:log)
 priority=DownCameraPriority(node,7)
 detection=NS(class_id=7,pixel_x=1.,pixel_y=1.,confidence=-.5)
 msg=NS(header=NS(stamp=NS(sec=1,nanosec=0)),detections=[detection])
 node._down_detection_events.append((1,clock.t,'down_left',msg))
 assert priority.update()==('down_left',detection)
 assert best_detection(msg,7) is detection

def test_hit_visual_fallback_success_ends_remaining_colors(monkeypatch):
 monkeypatch.setattr(hit.rclpy,'ok',lambda:True)
 log,_=logger();events=[]
 node=NS(stopped=False,LIGHT_YELLOW=3,camera_extrinsics={'front_left':object()},_model_mapping=NS(model_class_id=lambda *a,**kw:5),_ensure_camera_extrinsics=lambda:True,get_logger=lambda:log)
 task=object.__new__(hit.RB26HitBallsTask);task._node=node
 task._params=hit.validate_hit_params({'order':['impact_ball_blue','impact_ball_red']})
 task._light=lambda *a:None;task._pose=lambda:(0,0,.2,0,0,0);task._set=lambda *a:None;task._observer=NS(select=lambda *a:None)
 def one():events.append(task._name);raise hit.ObservationFailure('no frame')
 task._one_ball=one;task._fallback=lambda msg:TaskOutcome.ok('blind fallback')
 result=task.execute()
 assert result and events==['impact_ball_blue']

def test_hit_alignment_valid_but_never_centered_still_returns_true(monkeypatch):
 monkeypatch.setattr(hit.rclpy,'ok',lambda:True)
 clock=Clock();log,logs=logger();rates=[]
 node=NS(stopped=False,LIGHT_YELLOW=3,LIGHT_GREEN=2,get_logger=lambda:log,_format_motion_context=lambda text:text)
 node._send_body_velocity=lambda **kw:(rates.append(kw.get('yaw_rate_deg_s',0)) or True,'')
 task=object.__new__(hit.RB26HitBallsTask);task._node=node;task._params=hit.validate_hit_params({});task._name='blue';task._now=clock.now;task._sleep=clock.sleep;task._yaw_active=False
 frame=NS(eye='front_left',ray=np.array([1.,1.,0.]))
 task._observer=NS(cursor=lambda:0,first_eye='front_left',frames=lambda *a:[frame],stereo_center=lambda *a:None)
 task._pose=lambda:(0,0,.2,0,0,0);task._light=lambda *a:None;task._hold=lambda:None;task._flash=lambda *a:None
 assert task._align(3.) is True
 assert max(rates)==10. and any('仍未稳定' in x for x in logs)
