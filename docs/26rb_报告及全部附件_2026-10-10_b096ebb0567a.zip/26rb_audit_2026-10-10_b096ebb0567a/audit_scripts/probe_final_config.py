from pathlib import Path
import sys,json,yaml,shutil,hashlib,datetime
root=Path('work/audit_snapshot').resolve();live=Path('/home/doc049/dev/UUV/YouLong_AUV_Control_System');rel=Path('workspace_auv/src/uv_task/config/tasks/26rb_grab_ball_ring.yaml')
for p in (root/'workspace_auv/src').iterdir():
 if p.is_dir():sys.path.insert(0,str(p))
from uv_task.config_loader import load_task,load_mission,_flatten_params,TASK_SCHEMAS
out=Path('work/catalog');candidate=live/rel;copy=Path('work/final_live_overrides')/rel;copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(candidate,copy)
raw=yaml.safe_load(candidate.read_text());flat=_flatten_params(raw['params'],TASK_SCHEMAS['26rb_grab_ball_ring'],task_name='26rb_grab_ball_ring');errors={}
for label,path,loader in [('task',candidate,load_task),('mission',live/'workspace_auv/src/uv_task/config/missions/robocup_26.yaml',load_mission)]:
 try:loader(path);errors[label]='LOADED'
 except Exception as exc:errors[label]=type(exc).__name__+': '+str(exc)
result={'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'validation':errors,'flat_candidate_values_not_validated':flat}
(out/'final_candidate_parameters.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'final_candidate_load_probe.txt').write_text('\n'.join(k+': '+v for k,v in errors.items())+'\n');print(json.dumps({'validation':errors,'depths':{k:flat[k] for k in ['work_depth_m','golf_grab_depth_m','ring_grab_depth_m','ring_open_angle_deg','ring_close_angle_deg']}},ensure_ascii=False))
