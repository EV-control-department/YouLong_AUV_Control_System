from pathlib import Path
import ast,csv,json,hashlib
root=Path('work/audit_snapshot'); out=Path('work/catalog')
base=root/'workspace_auv/src/uv_task/uv_task'
names=['task_runner.py','26rb_hit_balls.py','26rb_gate_task.py','26rb_grab_ball_ring.py','26rb_grab_golf.py','26rb_drop_ball_target_rack.py','collection_frame_search.py']
selected={'set_servo','_set_task_phase_light','light_off','_send_action_goal','_send_body_velocity','_send_servo','_send_led','_set_pose','_restore_work_depth','_return_frame','_verify','_ring_servo','_orient_and_align_ring','_descend_to_depth','_mechanical_attempt','_run_target','_set','_hold','_turn','_look_at_preset','_observe','_neutral_yaw','_align','_cancel_line','_run_bline','_cruise_to_radius','_near_observation','_fallback','_one_ball','_velocity','_neutral','_action','_depth_hold','_flash','_reach_observation','_scan','_search','_fresh_after','_lateral','_fore_aft','_final_yaw','_pass','_park','_run_gate','_wait_for_detection','_flash_green','_send_horizontal_velocity','_stop_horizontal_velocity','_servo_horizontally','_prepare_claw','_apply_camera_gripper_offset','_wait_pre_descent_settle','_vertical_motion','_descend','_ascend','_verify_golf_removed','_return_to_recorded_pose','_pickup_attempt','_sleep','_wait','_wait_until','_observe_rack','_send_rack_velocity','_stop_rack_velocity','_servo_rack','_align_disc_claw','_align_hairpin_claw','_align_claw','_release_ball','_release_ring','_align_front','_cancel','_bline','send_goal_async','cancel_goal_async','wait_for_server'}
rows=[]; clocks=[]; failures=[]
class Visitor(ast.NodeVisitor):
 def __init__(self,path):self.path=path;self.stack=[]
 def visit_FunctionDef(self,n):
  self.stack.append(n.name);self.generic_visit(n);self.stack.pop()
 def visit_ClassDef(self,n):
  self.stack.append(n.name);self.generic_visit(n);self.stack.pop()
 def visit_Call(self,n):
  name=n.func.attr if isinstance(n.func,ast.Attribute) else n.func.id if isinstance(n.func,ast.Name) else ''
  if name in selected:rows.append([str(self.path.relative_to(root)),n.lineno,'.'.join(self.stack),name,ast.unparse(n)])
  if name in {'sleep','monotonic','time','wait','result','set_result','failed'}:
   clocks.append([str(self.path.relative_to(root)),n.lineno,'.'.join(self.stack),name,ast.unparse(n)])
  if name in {'failed','GateFailure','MotionFailure','ObservationFailure','PickupFailure'}:failures.append([str(self.path.relative_to(root)),n.lineno,'.'.join(self.stack),name,ast.unparse(n)])
  self.generic_visit(n)
for name in names:Visitor(base/name).visit(ast.parse((base/name).read_text()))
for filename,data in [('action_calls.csv',rows),('clock_wait_calls.csv',clocks),('failure_calls.csv',failures)]:
 with (out/filename).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['source','line','containing_function','call_name','source_expression']);w.writerows(data)
manifest=[]
for p in sorted(root.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  data=p.read_bytes();manifest.append({'path':str(p.relative_to(root)),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'snapshot_manifest_expanded.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'action_calls':len(rows),'clock_wait_calls':len(clocks),'failure_calls':len(failures),'snapshot_files':len(manifest)}))
