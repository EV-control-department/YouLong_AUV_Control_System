# 26rb审查附件

主报告：[`../26rb_全流程审查_2026-10-10_b096ebb0567a.md`](../26rb_全流程审查_2026-10-10_b096ebb0567a.md)。

- catalog：展开参数、调用点、失败构造、时间等待、节点/launch默认、场景实体、hash与安装差异。
- raw_configs：审查时的任务mission/独立任务、相机K/D、控制器、几何登记及真实启动profile。
- logs：各轮离线测试/构建日志及XML；包含失败和环境问题，不能仅凭文件名认为全部通过。
- audit_scripts：审查脚本与11个边界探针；不用于连接实艇。脚本路径按审查工作区和容器布局编写，复跑前需恢复匹配快照及ROS生成消息环境。
- frozen_sources.zip：关键源证据；不含权重、HAL库、Eigen和编译产物，不是独立完整可编译工程。仅含iwdg.c这个HAL配置证据例外。
- provenance：审查中两处launch首快照，配合catalog/live_drift.patch查看末次模型路径变化。

报告没有修改mission或控制逻辑。末次候选环松爪270°导致task/mission校验失败，见报告第20章及final_live_overrides；raw_configs/frozen_sources保留已测试基线。相机补测最终112通过1失败；固件154通过1失败1禁用；任务387、控制64、边界探针11通过。主机和Foxy重复执行同一任务/边界集合，不重复计为新用例。

归档日期：2026-10-10

当前 Git commit：`b096ebb0567aae8c8d922633a265b710404a0787`
